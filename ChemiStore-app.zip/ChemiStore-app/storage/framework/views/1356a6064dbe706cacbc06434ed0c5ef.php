<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>ChemiStore</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }

    header {
      background-color: #222;
      color: white;
      padding: 1rem;
      display: flex;
      align-items: center;
      position: relative;
      justify-content: center;
    }

    .nav-left {
      position: absolute;
      left: 1rem;
    }

    .nav-left a {
      text-decoration: none;
      margin-right: 10px;
      background-color: #000;
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
      font-weight: bold;
    }

    .nav-left a:hover {
      background-color: #333;
    }

    .title {
      margin: 0;
      font-size: 1.5rem;
    }

    h1 {
      text-align: center;
      margin: 1.5rem 0;
    }

    .grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 1.5rem;
      padding: 1rem 2rem;
    }

    .card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.2s ease-in-out;
      width: 100%;
      max-width: 300px;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 100px; /* Ajuste de tamaño de imagen */
      object-fit: cover;
    }

    .card-content {
      padding: 1rem;
    }

    .card-content h3 {
      margin: 0;
      font-size: 1.2rem;
      color: #333;
    }

    .card-content p {
      margin: 0.3rem 0;
      color: #555;
    }

    .price {
      font-weight: bold;
      color: #e91e63;
      margin-top: 0.5rem;
    }

    .btn {
      margin-top: 10px;
      background-color: #28a745;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      cursor: pointer;
      width: 100%;
      font-weight: bold;
      transition: background 0.3s;
    }

    .btn:hover {
      background-color: #218838;
    }

    footer {
      text-align: center;
      margin-top: 2rem;
      padding: 1rem;
      background-color: #222;
      color: white;
    }
  </style>
</head>
<body>

  <header>
    <div class="nav-left">
      <a href="<?php echo e(route('balones')); ?>">Ver Balones</a>
      <a href="<?php echo e(route('uniformes')); ?>">Ver Uniformes</a>
    </div>
    <h1 class="title">Bienvenido a ChemiStore</h1>
  </header>

  <h1>Camisetas disponibles</h1>

  <div class="grid">
    <?php $__currentLoopData = $camisetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camiseta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card">
        <img src="<?php echo e($camiseta->imagen_url ?? 'https://via.placeholder.com/300x200'); ?>" alt="<?php echo e($camiseta->Marca_camiseta); ?>">
        <div class="card-content">
          <h3><?php echo e($camiseta->Equipo_camiseta); ?></h3>
          <p>Marca: <?php echo e($camiseta->Marca_camiseta); ?></p>
          <p>Tamaño: <?php echo e($camiseta->Tamaño_camiseta); ?></p>
          <p>Tipo: <?php echo e($camiseta->Tipo_camiseta ?? 'N/A'); ?></p>
          <p class="price">$<?php echo e($camiseta->Precio_camiseta); ?></p>
          <button class="btn">Agregar al carrito</button>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <footer>
    &copy; <?php echo e(date('Y')); ?> ChemiStore. Todos los derechos reservados.
  </footer>

</body>
</html>
<?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/home.blade.php ENDPATH**/ ?>