<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Uniformes - ChemiStore</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }

    header {
      background-color: #222;
      color: white;
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .nav-left {
      display: flex;
      gap: 10px;
    }

    .nav-left a {
      text-decoration: none;
      background-color: rgb(0, 0, 0);
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
    }

    .nav-left a:hover {
      background-color: rgb(34, 34, 34);
    }

    header h1 {
      flex: 1;
      text-align: center;
      font-size: 1.8rem;
    }

    h2 {
      text-align: center;
      margin: 1.5rem 0;
    }

    .grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 1.5rem;
      padding: 1rem 2rem;
    }

    .card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.2s ease-in-out;
      width: 100%;
      max-width: 300px;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 180px;
      object-fit: cover;
    }

    .card-content {
      padding: 1rem;
    }

    .card-content h3 {
      margin: 0;
      font-size: 1.2rem;
      color: #333;
    }

    .card-content p {
      margin: 0.3rem 0;
      color: #555;
    }

    .price {
      font-weight: bold;
      color: #e91e63;
      margin-top: 0.5rem;
    }

    .btn {
      margin-top: 10px;
      background-color: #28a745;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      cursor: pointer;
      width: 100%;
      font-weight: bold;
      transition: background 0.3s;
    }

    .btn:hover {
      background-color: #218838;
    }

    footer {
      text-align: center;
      margin-top: 2rem;
      padding: 1rem;
      background-color: #222;
      color: white;
    }
  </style>
</head>
<body>

  <header>
    <div class="nav-left">
      <a href="<?php echo e(route('home')); ?>">Inicio</a>
      <a href="<?php echo e(route('balones')); ?>">Ver Balones</a>
    </div>
    <h1>Uniformes</h1>
  </header>

  <h2>Uniformes disponibles</h2>

  <div class="grid">
    <?php $__empty_1 = true; $__currentLoopData = $uniformes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uniforme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="card">
        <img src="<?php echo e($uniforme->imagen_url ?? 'https://via.placeholder.com/300x200'); ?>" alt="<?php echo e($uniforme->Marca_uniforme); ?>">
        <div class="card-content">
          <h3><?php echo e($uniforme->Equipo_uniforme); ?></h3>
          <p>Marca: <?php echo e($uniforme->Marca_uniforme); ?></p>
          <p>Talla: <?php echo e($uniforme->Talla_uniforme); ?></p>
          <p>Material: <?php echo e($uniforme->Material_uniforme); ?></p>
          <p class="price">$<?php echo e(number_format($uniforme->Precio_uniforme, 2, ',', '.')); ?></p>
          <button class="btn">Agregar al carrito</button>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p style="text-align: center;">No hay uniformes disponibles.</p>
    <?php endif; ?>
  </div>

  <footer>
    &copy; <?php echo e(date('Y')); ?> ChemiStore. Todos los derechos reservados.
  </footer>

</body>
</html>
<?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/uniformes.blade.php ENDPATH**/ ?>