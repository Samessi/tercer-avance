<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>ChemiStore</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }

    header {
      background-color: #222;
      color: white;
      padding: 1rem;
      text-align: center;
    }

    nav {
      text-align: center;
      margin: 1rem 0;
    }

    nav a {
      text-decoration: none;
      margin: 0 10px;
      background-color: #007bff;
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
    }

    nav a:hover {
      background-color: #0056b3;
    }

    h1 {
      text-align: center;
      margin: 1.5rem 0;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1.5rem;
      padding: 1rem 2rem;
    }

    .card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.2s ease-in-out;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .card-content {
      padding: 1rem;
    }

    .card-content h3 {
      margin: 0;
      font-size: 1.2rem;
      color: #333;
    }

    .card-content p {
      margin: 0.3rem 0;
      color: #555;
    }

    .price {
      font-weight: bold;
      color: #e91e63;
      margin-top: 0.5rem;
    }

    .btn {
      margin-top: 10px;
      background-color: #28a745;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      cursor: pointer;
      width: 100%;
      font-weight: bold;
      transition: background 0.3s;
    }

    .btn:hover {
      background-color: #218838;
    }

    footer {
      text-align: center;
      margin-top: 2rem;
      padding: 1rem;
      background-color: #222;
      color: white;
    }
  </style>
</head>
<body>

  <header>
    <h1>Bienvenido a ChemiStore</h1>
  </header>

  <nav>
    <a href="<?php echo e(route('balones.index')); ?>">Ver Balones</a>
    <a href="<?php echo e(route('uniformes.index')); ?>">Ver Uniformes</a>
  </nav>

  <h1>Camisetas disponibles</h1>

  <div class="grid">
    <?php $__currentLoopData = $camisetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camiseta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card">
        <img src="<?php echo e($camiseta->imagen_url ?? 'https://via.placeholder.com/300x200'); ?>" alt="<?php echo e($camiseta->Marca_camiseta); ?>">
        <div class="card-content">
          <h3><?php echo e($camiseta->Marca_camiseta); ?></h3>
          <p>Tamaño: <?php echo e($camiseta->Tamano_camiseta); ?></p>
          <p>Tipo: <?php echo e($camiseta->Tipo_camiseta ?? 'N/A'); ?></p>
          <p class="price">$<?php echo e($camiseta->Precio_camiseta); ?></p>
          <button class="btn">Agregar al carrito</button>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <footer>
    &copy; <?php echo e(date('Y')); ?> ChemiStore. Todos los derechos reservados.
  </footer>

</body>
</html><?php /**PATH C:\Users\emchz\Desktop\Laravel\Proyecto-LRV\ChemiStore-app\resources\views/home.blade.php ENDPATH**/ ?>