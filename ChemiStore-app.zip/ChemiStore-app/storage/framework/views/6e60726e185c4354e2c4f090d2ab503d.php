<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Balones - ChemiStore</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }

    header {
      background-color: #222;
      color: white;
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .nav-left {
      display: flex;
      gap: 10px;
    }

    .nav-left a {
      text-decoration: none;
      background-color: rgb(0, 0, 0);
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
    }

    .nav-left a:hover {
      background-color: rgb(34, 34, 34);
    }

    header h1 {
      flex: 1;
      text-align: center;
      font-size: 1.8rem;
    }

    h2 {
      text-align: center;
      margin: 1.5rem 0;
    }

    .grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 1.5rem;
      padding: 1rem 2rem;
    }

    .card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.2s ease-in-out;
      width: 100%;
      max-width: 300px;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 180px;
      object-fit: cover;
    }

    .card-content {
      padding: 1rem;
    }

    .card-content h3 {
      margin: 0;
      font-size: 1.2rem;
      color: #333;
    }

    .card-content p {
      margin: 0.3rem 0;
      color: #555;
    }

    .price {
      font-weight: bold;
      color: #27ae60;
      margin-top: 0.5rem;
    }

    footer {
      text-align: center;
      margin-top: 2rem;
      padding: 1rem;
      background-color: #222;
      color: white;
    }
  </style>
</head>
<body>

  <header>
    <div class="nav-left">
      <a href="<?php echo e(route('home')); ?>">Inicio</a>
      <a href="<?php echo e(route('uniformes')); ?>">Ver Uniformes</a>
    </div>
    <h1>Balones</h1>
  </header>

  <h2>Balones disponibles</h2>

    <div class="grid">
      <?php $__empty_1 = true; $__currentLoopData = $balones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card">
          <img src="<?php echo e($balon->imagen_url ?? 'https://via.placeholder.com/300x180?text=Sin+Imagen'); ?>" alt="<?php echo e($balon->Marca_balon); ?>" />
          <div class="card-content">
            <h3><?php echo e($balon->Marca_balon); ?></h3>
            <p>Tamaño: <?php echo e($balon->Tamano_balon); ?></p>
            <p>Tipo: <?php echo e($balon->Tipo_balon); ?></p>
            <p class="price">$<?php echo e(number_format($balon->Precio_balon, 2, ',', '.')); ?></p>
            <button class="btn">Agregar al carrito</button>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No hay balones disponibles.</p>
      <?php endif; ?>
    </div>
  </main>

  <footer>
    © <?php echo e(date('Y')); ?> ChemiStore - Todos los derechos reservados
  </footer>

</body>
</html>
<?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/balones.blade.php ENDPATH**/ ?>