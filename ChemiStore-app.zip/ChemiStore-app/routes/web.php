<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CamisetaController;
use App\Http\Controllers\BalonController;
use App\Http\Controllers\UniformeController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\AuthController;

Route::get('/', [CamisetaController::class, 'index'])->name('home');
Route::get('/balones', [BalonController::class, 'index'])->name('balones');
Route::get('/uniformes', [UniformeController::class, 'index'])->name('uniformes');

Route::get('/registrar', [UsuarioController::class, 'create'])->name('usuarios.crear');
Route::post('/registrar', [UsuarioController::class, 'store'])->name('usuarios.registrar');

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');




