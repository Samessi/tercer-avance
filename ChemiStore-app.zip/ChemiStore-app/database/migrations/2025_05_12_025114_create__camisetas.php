<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('_camisetas', function (Blueprint $table) {
    $table->id();
    $table->string("Equipo_camiseta");
    $table->string("Marca_camiseta");
    $table->string("Tamaño_camiseta");
    $table->string("Tipo_camiseta")->nullable();
    $table->decimal("Precio_camiseta", 8, 2);
    $table->string("imagen_url")->nullable();
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('_camisetas');
    }
};
