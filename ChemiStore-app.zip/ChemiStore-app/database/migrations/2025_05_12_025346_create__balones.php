<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('_balones', function (Blueprint $table) {
    $table->id();
    $table->string("Marca_balon");       
    $table->integer("Tamaño_balon");      
    $table->string("Tipo_balon")->nullable(); 
    $table->decimal("Precio_balon", 8, 2);   
    $table->string("imagen_url")->nullable(); 
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('_balones');
    }
};
