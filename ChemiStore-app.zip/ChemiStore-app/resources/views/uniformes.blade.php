<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Uniformes - ChemiStore</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }

    header {
      background-color: #222;
      color: white;
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .nav-left {
      display: flex;
      gap: 10px;
    }

    .nav-left a {
      text-decoration: none;
      background-color: rgb(0, 0, 0);
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
    }

    .nav-left a:hover {
      background-color: rgb(34, 34, 34);
    }

    header h1 {
      flex: 1;
      text-align: center;
      font-size: 1.8rem;
    }

    h2 {
      text-align: center;
      margin: 1.5rem 0;
    }

    .grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 1.5rem;
      padding: 1rem 2rem;
    }

    .card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.2s ease-in-out;
      width: 100%;
      max-width: 300px;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 180px;
      object-fit: cover;
    }

    .card-content {
      padding: 1rem;
    }

    .card-content h3 {
      margin: 0;
      font-size: 1.2rem;
      color: #333;
    }

    .card-content p {
      margin: 0.3rem 0;
      color: #555;
    }

    .price {
      font-weight: bold;
      color: #e91e63;
      margin-top: 0.5rem;
    }

    .btn {
      margin-top: 10px;
      background-color: #28a745;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      cursor: pointer;
      width: 100%;
      font-weight: bold;
      transition: background 0.3s;
    }

    .btn:hover {
      background-color: #218838;
    }

    footer {
      text-align: center;
      margin-top: 2rem;
      padding: 1rem;
      background-color: #222;
      color: white;
    }
  </style>
</head>
<body>

  <header>
    <div class="nav-left">
      <a href="{{ route('home') }}">Inicio</a>
      <a href="{{ route('balones') }}">Ver Balones</a>
    </div>
    <h1>Uniformes</h1>
  </header>

  <h2>Uniformes disponibles</h2>

  <div class="grid">
    @forelse ($uniformes as $uniforme)
      <div class="card">
        <img src="{{ $uniforme->imagen_url ?? 'https://via.placeholder.com/300x200' }}" alt="{{ $uniforme->Marca_uniforme }}">
        <div class="card-content">
          <h3>{{ $uniforme->Equipo_uniforme }}</h3>
          <p>Marca: {{ $uniforme->Marca_uniforme }}</p>
          <p>Talla: {{ $uniforme->Talla_uniforme }}</p>
          <p>Material: {{ $uniforme->Material_uniforme }}</p>
          <p class="price">${{ number_format($uniforme->Precio_uniforme, 2, ',', '.') }}</p>
          <button class="btn">Agregar al carrito</button>
        </div>
      </div>
    @empty
      <p style="text-align: center;">No hay uniformes disponibles.</p>
    @endforelse
  </div>

  <footer>
    &copy; {{ date('Y') }} ChemiStore. Todos los derechos reservados.
  </footer>

</body>
</html>
