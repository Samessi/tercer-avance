<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario - ChemiStore</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            border: none;
            color: white;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .success {
            color: green;
            margin-bottom: 10px;
            text-align: center;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 6px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Registro de Usuario</h2>

        {{-- Mensaje éxito --}}
        @if (session('success'))
            <p class="success">{{ session('success') }}</p>
        @endif

        {{-- Errores de validación --}}
        @if ($errors->any())
            @foreach ($errors->all() as $error)
                <p class="error">{{ $error }}</p>
            @endforeach
        @endif

        <form action="{{ route('usuarios.registrar') }}" method="POST">
            @csrf
            <input type="text" name="Nombre" placeholder="Nombre" value="{{ old('Nombre') }}" required>
            <input type="text" name="Apellido" placeholder="Apellido" value="{{ old('Apellido') }}" required>
            <input type="text" name="Telefono" placeholder="Teléfono" value="{{ old('Telefono') }}" required>
            <input type="email" name="Correo" placeholder="Correo" value="{{ old('Correo') }}" required>
            
            <!-- Campos para password -->
            <input type="password" name="password" placeholder="Contraseña" required>
            <input type="password" name="password_confirmation" placeholder="Confirmar Contraseña" required>
            
            <button type="submit">Registrarse</button>
        </form>
    </div>
</body>
</html>