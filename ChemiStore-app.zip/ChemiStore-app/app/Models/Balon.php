<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Balon extends Model
{
    use HasFactory;

    protected $table = '_balones';

    protected $fillable = [
        'Marca_balon',
        'Tamaño_balon',
        'Tipo_balon',
        'Precio_balon',
        'imagen_url',
    ];
}