<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Usuario extends Authenticatable
{
    use Notifiable;

    // Nombre de la tabla en la base de datos
    protected $table = 'usuarios';

    // Campos que se pueden asignar masivamente
    protected $fillable = [
        'Nombre',
        'Apellido',
        'Telefono',
        'Correo',
        'password',
    ];

    // Campos que no quieres que se muestren en arrays o JSON
    protected $hidden = [
        'password',
        'remember_token',
    ];

    // Para usar timestamps (created_at, updated_at)
    public $timestamps = true;

    // Si quieres que el campo único para autenticación sea "Correo" en lugar de "email"
    public function getAuthIdentifierName()
    {
        return 'Correo';
    }
}
