<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Camiseta extends Model
{
    use HasFactory;

    protected $table = '_camisetas';

    protected $fillable = [
        'Equipo_camiseta',
        'Marca_camiseta',
        'Tamaño_camiseta',
        'Tipo_camiseta',
        'Precio_camiseta',
        'imagen_url',
    ];
}