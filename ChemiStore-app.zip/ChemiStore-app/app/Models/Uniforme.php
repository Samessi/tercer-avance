<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Uniforme extends Model
{
    use HasFactory;

    protected $table = '_uniformes';

    protected $fillable = [
        'Equipo_uniforme',
        'Marca_uniforme',
        'Tamaño_uniforme',
        'Tipo_uniforme',
        'Precio_uniforme',
        'imagen_url',
    ];
}