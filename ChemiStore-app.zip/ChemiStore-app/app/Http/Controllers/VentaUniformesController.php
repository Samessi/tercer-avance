<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VentaUniformesController extends Controller
{
        public function index()
    {
        $ventas = venta_uniforme::all();
        return view('ventas.uniformes', compact('ventas'));
    }
}
