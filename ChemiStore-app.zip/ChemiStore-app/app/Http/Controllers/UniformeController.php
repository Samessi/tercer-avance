<?php

namespace App\Http\Controllers;

use App\Models\Uniforme;
use Illuminate\Http\Request;

class UniformeController extends Controller
{
    public function index()
    {
        $uniformes = Uniforme::all();
        return view('uniformes', compact('uniformes'));
    }
}