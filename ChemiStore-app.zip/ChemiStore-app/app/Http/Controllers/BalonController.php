<?php

namespace App\Http\Controllers;

use App\Models\Balon;
use Illuminate\Http\Request;

class BalonController extends Controller
{
    public function index()
    {
        $balones = Balon::all();
        return view('balones', compact('balones'));
    }
}