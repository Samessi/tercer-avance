<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VentaCamisaController extends Controller
{
    public function index()
    {
        $ventas = venta_camisa::all();
        return view('ventas.camisas', compact('ventas'));
    }
}
